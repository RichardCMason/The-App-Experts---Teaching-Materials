library(data.table)

data <- fread('Downloads/moore.csv')
data$V2 <- as.numeric(gsub(',', '', unlist(lapply(unlist(lapply(
  data$V2, function(x) gsub('[A-Za-z +]', '', unlist(strsplit(x, '\\['))[1]))),
  function(y) gsub('~+', '', y)))))
data[, V2:=log2(V2)]

data$V3 <- unlist(lapply(data$V3, 
                         function(x) as.numeric(unlist(strsplit(x, '\\['))[1])))

fit <- lm(data$V2 ~ data$V3)
summary(fit)

#obtaining slope or weight 1:
w1 <- (mean(data$V3 * data$V2) - mean(data$V2) * mean(data$V3))/(
  mean(data$V3 ** 2) - mean(data$V3) ** 2)
w0 <- mean(data$V2) - w1*mean(data$V3)
y_fitted <- w0 + w1 * data$V3

r_squared <- (sum((y_fitted - mean(data$V2)) ** 2)) / (
  sum((data$V2 - mean(data$V2)) ** 2))